package com.onev.assistant

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.util.Locale

/**
 * 1V ka dimaag: foreground service jo lagataar "1V" sunta hai,
 * phir command chalata hai aur jawab bolta hai. Sab offline.
 */
class AssistantService : Service(), TextToSpeech.OnInitListener {

    companion object {
        @Volatile
        var running = false
        val history = StringBuilder()
        var listener: ((String) -> Unit)? = null
        const val ACTION_STOP = "com.onev.assistant.STOP"
        const val ACTION_SAY = "com.onev.assistant.SAY"
        const val ACTION_RING = "com.onev.assistant.RING"
        const val ACTION_CALL_OVER = "com.onev.assistant.CALL_OVER"
        const val EXTRA_TEXT = "text"
        private const val CHANNEL_ID = "onev_channel"

        // "1V" bolne par recognizer ye sab likh sakta hai: 1V, one V, van vee, वन वी ...
        val WAKE_RE = Regex(
            """(?<![\p{L}\p{N}])((1|one|van|wan|vun)[\s\-.]*(vee|vi|ve|v|वी|वि)|वन्?[\s\-.]*(वी|वि))(?![\p{L}\p{N}])""",
            RegexOption.IGNORE_CASE
        )
        val ACCEPT_RE = Regex(
            """utha|receive|recieve|answer|pick|accept|\bhaan\b|\bhan\b|\byes\b|le lo|उठा|रिसीव|हाँ|हां|ले लो""",
            RegexOption.IGNORE_CASE
        )
        val DECLINE_RE = Regex(
            """kaat|kat do|\bcut\b|decline|reject|cancel|nahi|nahin|\bno\b|\bmat\b|काट|कट|नहीं|रिजेक्ट|मत""",
            RegexOption.IGNORE_CASE
        )
        val EXIT_RE = Regex(
            """\b(exit|quit|bye|alvida)\b|band ho ja|बंद हो जा|अलविदा""",
            RegexOption.IGNORE_CASE
        )

        fun logLine(s: String) {
            history.append(s).append('\n')
            if (history.length > 8000) history.delete(0, 3000)
            listener?.invoke(s)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var started = false
    private var listening = false
    private var speaking = false
    private var awaitingCommand = false
    private var stopWhenDone = false
    private var errorHintShown = false
    private lateinit var router: CommandRouter
    private val prefs by lazy { getSharedPreferences("onev", MODE_PRIVATE) }

    // Offline (Vosk) engine
    private var voskModel: Model? = null
    private var voskService: SpeechService? = null
    private var useVosk = false
    private var voskLoading = false

    // Incoming call
    private var ringing = false
    private var ringSource = 0 // 0 koi nahi, 1 SIM call, 2 internet call (WhatsApp/Instagram)
    private var telephonyBusy = false
    private var voipBusy = false
    private var voipLabel: String? = null
    private var lastNumber: String? = null
    private var phoneReceiver: BroadcastReceiver? = null
    private val inCall: Boolean get() = telephonyBusy || voipBusy
    private val ringAnnounce = Runnable { announceRing() }
    private val ringTimeout = Runnable { if (ringSource == 2) endRing() }

    private val restartRunnable = Runnable { startListening() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        router = CommandRouter(this) { seconds, label -> scheduleReminder(seconds, label) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_SAY) {
            val text = intent?.getStringExtra(EXTRA_TEXT)
            if (started && !text.isNullOrBlank()) say(text)
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_RING) {
            if (started) {
                voipLabel = intent?.getStringExtra(EXTRA_TEXT)
                ringSource = 2
                ringing = true
                main.removeCallbacks(ringAnnounce)
                main.postDelayed(ringAnnounce, 300)
                main.removeCallbacks(ringTimeout)
                main.postDelayed(ringTimeout, 45000)
            }
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_CALL_OVER) {
            voipBusy = false
            VoipCalls.clear()
            if (ringSource == 2) endRing()
            scheduleRestart(500)
            return START_NOT_STICKY
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "1V", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification)
        }
        if (!started) {
            started = true
            logLine("▶ 1V shuru ho raha hai...")
            registerPhoneReceiver()
            tts = TextToSpeech(this, this)
        }
        return START_NOT_STICKY
    }

    // Reminder AlarmManager se chalta hai, to service band ho tab bhi notification aata hai
    private fun scheduleReminder(seconds: Int, label: String) {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val text = if (label.isBlank()) "Aapka timer poora hua" else label
        val i = Intent(this, ReminderReceiver::class.java).putExtra(ReminderReceiver.EXTRA_TEXT, text)
        val pi = PendingIntent.getBroadcast(
            this, (System.currentTimeMillis() and 0x7fffffff).toInt(), i,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + seconds * 1000L, pi)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("1V sun raha hai")
            .setContentText("'1V' bolkar jagayein")
            .setContentIntent(open)
            .addAction(0, "Band karo", stop)
            .setOngoing(true)
            .build()
    }

    // ---------- Text-to-speech ----------
    override fun onInit(status: Int) {
        main.post {
            val t = tts
            if (!running || t == null) return@post
            if (status != TextToSpeech.SUCCESS) {
                logLine("⚠ Bolne wala engine shuru nahi hua (sirf text dikhega)")
                startEngine(true)
                return@post
            }
            for (l in listOf(Locale("hi", "IN"), Locale("en", "IN"), Locale.US)) {
                val r = t.setLanguage(l)
                if (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED) break
            }
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) = finishedSpeaking()

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) = finishedSpeaking()
            })
            ttsReady = true
            startEngine(false)
            say("Namaste! Main 1V hoon. Mujhe jagane ke liye 1V bolein.")
        }
    }

    private fun finishedSpeaking() {
        main.post {
            speaking = false
            if (stopWhenDone) {
                stopSelf()
            } else {
                if (ringing) {
                    main.removeCallbacks(ringAnnounce)
                    main.postDelayed(ringAnnounce, 6000) // jab tak faisla na ho, dobara poochho
                }
                if (useVosk) scheduleRestart(350) else startListening()
            }
        }
    }

    private fun say(text: String) {
        logLine("🤖 $text")
        stopListening()
        speaking = true
        val res = if (ttsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
        } else null
        if (res != TextToSpeech.SUCCESS) {
            speaking = false
            if (stopWhenDone) stopSelf() else scheduleRestart(300)
        }
    }

    // ---------- Speech-to-text ----------
    private fun lang(): String = prefs.getString("lang", "hi-IN") ?: "hi-IN"

    // ---------- Offline engine (Vosk) ----------
    private fun startEngine(startNow: Boolean) {
        val l = lang()
        val wantVosk = prefs.getString("engine", "vosk") == "vosk"
        if (wantVosk && ModelManager.isReady(this, l)) {
            voskLoading = true
            logLine("⏳ Offline voice model load ho raha hai...")
            Thread {
                try {
                    val m = Model(ModelManager.modelPath(this, l))
                    main.post {
                        if (!running) {
                            m.close()
                            return@post
                        }
                        voskModel = m
                        try {
                            val rec = Recognizer(m, 16000.0f)
                            val svc = SpeechService(rec, 16000.0f)
                            svc.startListening(voskListener)
                            voskService = svc
                            useVosk = true
                            voskLoading = false
                            listening = true
                            if (speaking || ringing) {
                                svc.setPause(true)
                                listening = false
                            }
                            logLine("✅ Offline engine chalu (bolne ke liye internet nahi chahiye)")
                        } catch (e: Throwable) {
                            fallbackToGoogle("Offline engine shuru nahi hua: ${e.message}")
                        }
                    }
                } catch (e: Throwable) {
                    main.post { fallbackToGoogle("Offline model load nahi hua: ${e.message}") }
                }
            }.start()
        } else {
            if (wantVosk) {
                logLine("ℹ Offline voice model abhi download nahi hua. App me 'Offline voice model download' dabao. Tab tak Google speech chalega.")
            }
            muteBeeps()
            if (startNow) startListening()
        }
    }

    private fun fallbackToGoogle(why: String) {
        logLine("⚠ $why. Google speech use kar raha hoon")
        voskLoading = false
        useVosk = false
        muteBeeps()
        startListening()
    }

    private val voskListener = object : org.vosk.android.RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {}
        override fun onResult(hypothesis: String?) {
            onVoskText(hypothesis)
        }

        override fun onFinalResult(hypothesis: String?) {}
        override fun onError(exception: Exception?) {
            main.post { logLine("⚠ Mic/engine error: ${exception?.message}") }
        }

        override fun onTimeout() {}
    }

    private fun onVoskText(h: String?) {
        val raw = h ?: return
        val text = try {
            JSONObject(raw).optString("text").trim()
        } catch (e: Exception) {
            ""
        }
        if (text.isEmpty()) return
        main.post { if (running && !speaking) handle(text) }
    }

    private fun startListening() {
        if (!running || speaking || listening || voskLoading || inCall) return
        if (useVosk) {
            voskService?.setPause(false)
            listening = true
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            logLine("⚠ Is phone me speech recognition nahi mila (Google app install/update karo)")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(recognitionListener)
            }
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang())
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try {
            listening = true
            recognizer?.startListening(i)
        } catch (e: Exception) {
            listening = false
            recreateRecognizer()
            scheduleRestart(1000)
        }
    }

    private fun stopListening() {
        main.removeCallbacks(restartRunnable)
        if (listening) {
            try {
                if (useVosk) voskService?.setPause(true) else recognizer?.cancel()
            } catch (e: Exception) {
            }
            listening = false
        }
    }

    private fun recreateRecognizer() {
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
        }
        recognizer = null
        listening = false
    }

    private fun scheduleRestart(ms: Long) {
        main.removeCallbacks(restartRunnable)
        main.postDelayed(restartRunnable, ms)
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            listening = false
            if (!running) return
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                logLine("⚠ Mic permission nahi hai")
                stopSelf()
                return
            }
            awaitingCommand = false
            router.clearPending()
            // 2 = network, 12/13 = language/offline pack missing
            if (error == 2 || error == 12 || error == 13) {
                if (!errorHintShown) {
                    errorHintShown = true
                    logLine("⚠ Offline speech pack chahiye: app me 'Offline speech pack' button dabao (ya Settings > Google > Voice > Offline speech recognition me Hindi/English download karo)")
                }
                scheduleRestart(3000)
                return
            }
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) {
                recreateRecognizer()
            }
            scheduleRestart(
                if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) 200 else 800
            )
        }

        override fun onResults(results: Bundle?) {
            listening = false
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull().orEmpty().trim()
            handle(text)
        }
    }

    // ---------- Command handling ----------
    private fun handle(raw: String) {
        val text = Numbers.normalize(raw)
        if (text.isBlank()) {
            awaitingCommand = false
            router.clearPending()
            scheduleRestart(200)
            return
        }
        if (ringing) {
            // call aa raha hai: "1V" bole bina bhi "utha lo" / "kaat do" sunna hai
            val low = text.lowercase(Locale.getDefault())
            when {
                DECLINE_RE.containsMatchIn(low) -> decideCall(false)
                ACCEPT_RE.containsMatchIn(low) -> decideCall(true)
                else -> scheduleRestart(100)
            }
            return
        }
        if (awaitingCommand && router.hasPending) {
            awaitingCommand = false
            logLine("👤 $text")
            say(router.confirm(text))
            return
        }
        val cmd: String
        if (awaitingCommand) {
            awaitingCommand = false
            logLine("👤 $text")
            cmd = text
        } else {
            val m = WAKE_RE.find(text)
            if (m == null) {
                // wake word nahi mila: privacy ke liye na log karo na save karo
                scheduleRestart(100)
                return
            }
            val rest = text.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?', '।')
            logLine("👤 $text")
            if (rest.length <= 2) {
                awaitingCommand = true
                say("Haan, bataiye?")
                return
            }
            cmd = rest
        }
        if (EXIT_RE.containsMatchIn(cmd)) {
            stopWhenDone = true
            say("Alvida! 1V band ho raha hai.")
            return
        }
        val reply = router.route(cmd)
        awaitingCommand = router.hasPending // "Bhejun? haan/nahi" ka jawab bina "1V" bole sunna hai
        say(reply)
    }

    // ---------- Incoming call ----------
    private fun registerPhoneReceiver() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            logLine("ℹ Call uthane/kaatne ke liye Phone permission do (app dobara shuru karo)")
            return
        }
        val r = object : BroadcastReceiver() {
            @Suppress("DEPRECATION")
            override fun onReceive(c: Context?, i: Intent?) {
                if (i?.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
                val st = i?.getStringExtra(TelephonyManager.EXTRA_STATE)
                val num = i?.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                main.post { onPhoneState(st, num) }
            }
        }
        ContextCompat.registerReceiver(
            this, r, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED),
            ContextCompat.RECEIVER_EXPORTED
        )
        phoneReceiver = r
    }

    private fun onPhoneState(state: String?, number: String?) {
        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                if (!number.isNullOrBlank()) lastNumber = number
                if (ringSource != 1) {
                    ringSource = 1
                    ringing = true
                    main.removeCallbacks(ringAnnounce)
                    main.postDelayed(ringAnnounce, 700) // number doosre broadcast me aa sakta hai
                }
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                telephonyBusy = true
                endRing()
                stopListening()
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                telephonyBusy = false
                endRing()
                lastNumber = null
                scheduleRestart(500)
            }
        }
    }

    private fun endRing() {
        ringing = false
        ringSource = 0
        main.removeCallbacks(ringAnnounce)
        main.removeCallbacks(ringTimeout)
    }

    private fun announceRing() {
        if (!ringing || !running) return
        val who = if (ringSource == 2) voipLabel else lastNumber?.let { router.nameForNumber(it) ?: it }
        say(
            if (who.isNullOrBlank()) "Koi call aa raha hai. Utha loon ya kaat doon?"
            else "$who ka call aa raha hai. Utha loon ya kaat doon?"
        )
    }

    private fun decideCall(accept: Boolean) {
        val src = ringSource
        endRing()
        val ok = if (src == 2) VoipCalls.act(accept) else CallControl.act(this, accept)
        if (accept) {
            if (ok) {
                logLine("📞 Call utha liya")
                if (src == 2) voipBusy = true
                stopListening()
            } else {
                say("Call utha nahi paya. Phone ki Answer calls permission check karo")
            }
        } else {
            say(if (ok) "Call kaat diya" else "Call kaat nahi paya. Permission check karo")
        }
    }

    // Recognizer ki beep band rakhne ke liye system/notification awaaz band (stop par wapas)
    private fun muteBeeps() = BeepGuard.mute(this)

    private fun restoreBeeps() = BeepGuard.restore(this)

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        recreateRecognizer()
        try {
            voskService?.cancel()
            voskService?.shutdown()
        } catch (e: Throwable) {
        }
        voskService = null
        try {
            voskModel?.close()
        } catch (e: Throwable) {
        }
        voskModel = null
        phoneReceiver?.let {
            try {
                unregisterReceiver(it)
            } catch (e: Exception) {
            }
        }
        phoneReceiver = null
        VoipCalls.clear()
        tts?.stop()
        tts?.shutdown()
        tts = null
        restoreBeeps()
        logLine("⏹ 1V band ho gaya")
        super.onDestroy()
    }
}

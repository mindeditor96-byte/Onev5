package com.onev.assistant

import java.util.Locale

/**
 * Offline (Vosk) engine "saath", "साठ" jaise number words likhta hai, digits nahi.
 * Ye unko digits me badalta hai: "नौ आठ सात छह पांच चार तीन दो एक शून्य" -> 9876543210,
 * "सात तीस बजे" -> "7 30 बजे", "twenty five" -> 25.
 */
object Numbers {
    private val EN: Map<String, Int> = mapOf(
        "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6,
        "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12,
        "thirteen" to 13, "fourteen" to 14, "fifteen" to 15, "sixteen" to 16, "seventeen" to 17,
        "eighteen" to 18, "nineteen" to 19, "twenty" to 20, "thirty" to 30, "forty" to 40,
        "fifty" to 50, "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90, "hundred" to 100
    )

    private val HI: Map<String, Int> = mapOf(
        "शून्य" to 0, "जीरो" to 0, "ज़ीरो" to 0, "एक" to 1, "दो" to 2, "तीन" to 3, "चार" to 4,
        "पांच" to 5, "पाँच" to 5, "छह" to 6, "छः" to 6, "छे" to 6, "सात" to 7, "आठ" to 8, "नौ" to 9,
        "दस" to 10, "ग्यारह" to 11, "बारह" to 12, "तेरह" to 13, "चौदह" to 14, "पंद्रह" to 15,
        "पन्द्रह" to 15, "सोलह" to 16, "सत्रह" to 17, "अठारह" to 18, "उन्नीस" to 19, "बीस" to 20,
        "इक्कीस" to 21, "बाईस" to 22, "तेईस" to 23, "चौबीस" to 24, "पच्चीस" to 25, "छब्बीस" to 26,
        "सत्ताईस" to 27, "अट्ठाईस" to 28, "अठ्ठाईस" to 28, "उनतीस" to 29, "तीस" to 30, "इकतीस" to 31,
        "बत्तीस" to 32, "तैंतीस" to 33, "चौंतीस" to 34, "पैंतीस" to 35, "छत्तीस" to 36, "सैंतीस" to 37,
        "अड़तीस" to 38, "उनतालीस" to 39, "उन्तालीस" to 39, "चालीस" to 40, "इकतालीस" to 41,
        "बयालीस" to 42, "तैंतालीस" to 43, "चौवालीस" to 44, "चवालीस" to 44, "पैंतालीस" to 45,
        "छियालीस" to 46, "सैंतालीस" to 47, "अड़तालीस" to 48, "उनचास" to 49, "पचास" to 50,
        "इक्यावन" to 51, "बावन" to 52, "तिरपन" to 53, "तिरेपन" to 53, "चौवन" to 54, "पचपन" to 55,
        "छप्पन" to 56, "सत्तावन" to 57, "अट्ठावन" to 58, "उनसठ" to 59, "साठ" to 60, "इकसठ" to 61,
        "बासठ" to 62, "तिरसठ" to 63, "चौंसठ" to 64, "पैंसठ" to 65, "छियासठ" to 66, "सड़सठ" to 67,
        "अड़सठ" to 68, "उनहत्तर" to 69, "सत्तर" to 70, "इकहत्तर" to 71, "बहत्तर" to 72, "तिहत्तर" to 73,
        "चौहत्तर" to 74, "पचहत्तर" to 75, "छिहत्तर" to 76, "सतहत्तर" to 77, "अठहत्तर" to 78,
        "उनासी" to 79, "अस्सी" to 80, "इक्यासी" to 81, "बयासी" to 82, "तिरासी" to 83, "चौरासी" to 84,
        "पचासी" to 85, "छियासी" to 86, "सत्तासी" to 87, "अठासी" to 88, "नवासी" to 89, "नब्बे" to 90,
        "इक्यानवे" to 91, "बानवे" to 92, "तिरानवे" to 93, "चौरानवे" to 94, "पचानवे" to 95,
        "छियानवे" to 96, "सत्तानवे" to 97, "अट्ठानवे" to 98, "निन्यानवे" to 99, "सौ" to 100
    )

    // "दो" (2 ya "kar do") aur "एक" (1 ya "ek") dono matlab ke hote hain, isliye sirf sandarbh dekh kar
    private val AMBIGUOUS = setOf("एक", "दो")
    private val UNITS = setOf(
        "बजे", "मिनट", "सेकंड", "सेकेंड", "घंटे", "घंटा", "प्रतिशत", "परसेंट", "percent",
        "minute", "minutes", "second", "seconds", "hour", "hours"
    )
    private const val DEV_DIGITS = "०१२३४५६७८९"

    fun normalize(text: String): String {
        var s = text
        for (i in DEV_DIGITS.indices) s = s.replace(DEV_DIGITS[i], '0' + i)
        val tk = s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tk.isEmpty()) return s.trim()
        val words = tk.map { it.trim(',', '.', '!', '?', '।').lowercase(Locale.ROOT) }
        val isEn = words.map { EN.containsKey(it) }
        val vals: List<Int?> = words.map { EN[it] ?: HI[it] }
        val num = BooleanArray(tk.size)
        for (i in tk.indices) {
            if (vals[i] != null && words[i] !in AMBIGUOUS) num[i] = true
        }
        repeat(3) {
            for (i in tk.indices) {
                if (vals[i] == null || num[i]) continue
                val prev = i > 0 && num[i - 1]
                val next = i + 1 < tk.size && (num[i + 1] || words[i + 1] in UNITS)
                if (prev || next) num[i] = true
            }
        }
        val out = ArrayList<String>()
        var i = 0
        while (i < tk.size) {
            if (!num[i]) {
                out.add(tk[i])
                i++
                continue
            }
            val run = ArrayList<Int>()
            var j = i
            while (j < tk.size && num[j]) {
                var v = vals[j] ?: 0
                val nxt = if (j + 1 < tk.size && num[j + 1] && isEn[j + 1]) vals[j + 1] ?: 0 else 0
                // English: "twenty five" -> 25
                if (isEn[j] && v in 20..90 && v % 10 == 0 && nxt in 1..9) {
                    v += nxt
                    j++
                }
                run.add(v)
                j++
            }
            if (run.size >= 3 && run.all { it in 0..9 }) out.add(run.joinToString(""))
            else for (v in run) out.add(v.toString())
            i = j
        }
        return out.joinToString(" ")
    }
}

package com.onev.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionSupport
import android.speech.RecognitionSupportCallback
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var logView: TextView
    private lateinit var statusView: TextView
    private lateinit var toggleBtn: Button
    private lateinit var langBtn: Button
    private lateinit var packBtn: Button
    private lateinit var accessBtn: Button
    private lateinit var confirmBtn: Button
    private lateinit var modelBtn: Button
    private lateinit var notifBtn: Button
    private var packRecognizer: SpeechRecognizer? = null
    private lateinit var scroll: ScrollView
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("onev", MODE_PRIVATE) }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (granted(Manifest.permission.RECORD_AUDIO)) startAssistant()
            else Toast.makeText(this, "Mic permission zaroori hai", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        logView = findViewById(R.id.logText)
        statusView = findViewById(R.id.statusText)
        toggleBtn = findViewById(R.id.btnToggle)
        langBtn = findViewById(R.id.btnLang)
        packBtn = findViewById(R.id.btnPack)
        accessBtn = findViewById(R.id.btnAccess)
        confirmBtn = findViewById(R.id.btnConfirm)
        modelBtn = findViewById(R.id.btnModel)
        notifBtn = findViewById(R.id.btnNotif)
        modelBtn.setOnClickListener { onModelDownload() }
        notifBtn.setOnClickListener {
            Toast.makeText(this, "List me '1V Auto Send' ko ON karo", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        confirmBtn.setOnClickListener {
            prefs.edit().putBoolean("confirm_send", !prefs.getBoolean("confirm_send", true)).apply()
            updateUi()
        }
        scroll = findViewById(R.id.scrollLog)

        toggleBtn.setOnClickListener { onToggle() }
        packBtn.setOnClickListener { onOfflinePack() }
        accessBtn.setOnClickListener {
            Toast.makeText(this, "List me '1V Auto Send' dhundo aur ON karo", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        langBtn.setOnClickListener {
            val next = if (lang() == "hi-IN") "en-IN" else "hi-IN"
            prefs.edit().putString("lang", next).apply()
            Toast.makeText(this, "Bhasha badli. 1V ko band karke dobara shuru karo", Toast.LENGTH_LONG).show()
            updateUi()
        }
    }

    override fun onResume() {
        super.onResume()
        if (!AssistantService.running) BeepGuard.restore(this) // crash ke baad awaaz wapas
        logView.text = AssistantService.history.toString()
        AssistantService.listener = { line ->
            runOnUiThread {
                logView.append(line + "\n")
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                updateUi()
            }
        }
        updateUi()
    }

    override fun onPause() {
        super.onPause()
        AssistantService.listener = null
    }

    private fun lang(): String = prefs.getString("lang", "hi-IN") ?: "hi-IN"

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun updateUi() {
        val on = AssistantService.running
        toggleBtn.text = if (on) "Band karo" else "Shuru karo"
        statusView.text = if (on) "Chalu hai. '1V' bolkar jagayein" else "Band hai"
        confirmBtn.text = if (prefs.getBoolean("confirm_send", true)) "Bhejne se pehle poochna: ON (badlo)"
        else "Bhejne se pehle poochna: OFF (badlo)"
        accessBtn.text = if (AutoSendService.isEnabled()) "Auto-send + Reels/Shorts control: ON ✅"
        else "Auto-send + Reels/Shorts control ON karo (Accessibility)"
        notifBtn.text = if (CallNotificationListener.enabled) "WhatsApp/Instagram call control: ON ✅"
        else "WhatsApp/Instagram call control ON karo (Notification access)"
        modelBtn.text = when {
            ModelManager.busy -> "Offline voice model download ho raha hai..."
            ModelManager.isReady(this, lang()) -> "Offline voice model: taiyaar ✅ (internet nahi chahiye)"
            else -> "Offline voice model download karo (~40 MB, ek baar)"
        }
        langBtn.text = if (lang() == "hi-IN") "Bhasha: Hindi / Hinglish (badlo)" else "Bhasha: English (badlo)"
    }

    private fun onToggle() {
        if (AssistantService.running) {
            startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
            ui.postDelayed({ updateUi() }, 600)
            return
        }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { !granted(it) }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray()) else startAssistant()
    }

    // ---------- Offline voice model (Vosk) ----------
    private fun onModelDownload() {
        val l = lang()
        if (ModelManager.isReady(this, l)) {
            Toast.makeText(this, "Offline model pehle se taiyaar hai ✅", Toast.LENGTH_LONG).show()
            return
        }
        if (ModelManager.busy) {
            Toast.makeText(this, "Download chal raha hai, ruko", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Download shuru (WiFi par karna behtar, ~40 MB)", Toast.LENGTH_LONG).show()
        updateUi()
        ModelManager.download(
            this, l,
            { msg -> runOnUiThread { statusView.text = msg } },
            { ok, err ->
                runOnUiThread {
                    Toast.makeText(
                        this,
                        if (ok) "Offline model taiyaar ✅ 1V ko band karke dobara shuru karo"
                        else "Download fail: $err",
                        Toast.LENGTH_LONG
                    ).show()
                    updateUi()
                }
            }
        )
    }

    // ---------- Google offline speech pack (backup) ----------
    private fun onOfflinePack() {
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            Toast.makeText(this, "Pehle 'Shuru karo' dabakar Mic permission do", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isRecognitionAvailable(this)) {
            checkAndDownloadPack()
        } else {
            openVoiceSettings()
        }
    }

    @RequiresApi(33)
    private fun checkAndDownloadPack() {
        val language = lang()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
        try {
            packRecognizer?.destroy()
        } catch (e: Exception) {
        }
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        packRecognizer = sr
        sr.checkRecognitionSupport(
            intent,
            ContextCompat.getMainExecutor(this),
            object : RecognitionSupportCallback {
                override fun onSupportResult(recognitionSupport: RecognitionSupport) {
                    val base = language.substringBefore('-')
                    val installed = recognitionSupport.installedOnDeviceLanguages
                        .any { it.substringBefore('-').equals(base, ignoreCase = true) }
                    if (installed) {
                        Toast.makeText(this@MainActivity, "$language offline pack install hai ✅", Toast.LENGTH_LONG).show()
                    } else {
                        try {
                            sr.triggerModelDownload(intent)
                            Toast.makeText(
                                this@MainActivity,
                                "$language pack download shuru hua. Thodi der baad ye button dobara dabakar check karo",
                                Toast.LENGTH_LONG
                            ).show()
                        } catch (e: Exception) {
                            openVoiceSettings()
                        }
                    }
                }

                override fun onError(error: Int) {
                    openVoiceSettings()
                }
            }
        )
    }

    private fun openVoiceSettings() {
        Toast.makeText(
            this,
            "Offline speech recognition me Hindi aur English download karo",
            Toast.LENGTH_LONG
        ).show()
        try {
            startActivity(Intent("android.settings.VOICE_INPUT_SETTINGS"))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    override fun onDestroy() {
        try {
            packRecognizer?.destroy()
        } catch (e: Exception) {
        }
        packRecognizer = null
        super.onDestroy()
    }

    private fun startAssistant() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Apps kholne ke liye 'Display over other apps' allow karo", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        ContextCompat.startForegroundService(this, Intent(this, AssistantService::class.java))
        ui.postDelayed({ updateUi() }, 600)
    }
}

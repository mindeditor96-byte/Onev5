package com.onev.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * WhatsApp chat khulne par Send button apne aap dabata hai.
 * Sirf tab kaam karta hai jab 1V ne abhi-abhi message taiyaar kiya ho (arm() se, 20 second ka window).
 * Manifest/config me sirf WhatsApp package allowed hain.
 */
class AutoSendService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AutoSendService? = null

        @Volatile
        private var armedUntil = 0L

        private val WA_PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")
        private val GESTURE_PKGS = setOf("com.google.android.youtube", "com.instagram.android")
        private val SEND_DESC = setOf("send", "भेजें", "भेजना", "भेजो")

        fun isEnabled() = instance != null

        fun arm(windowMs: Long = 20_000) {
            armedUntil = SystemClock.elapsedRealtime() + windowMs
        }

        private fun armed() = SystemClock.elapsedRealtime() < armedUntil
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!armed()) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() !in WA_PACKAGES) return
        val btn = findSend(root) ?: return
        if (btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            armedUntil = 0L // sirf ek baar
            AssistantService.logLine("✅ WhatsApp message bhej diya")
        }
    }

    fun foregroundPkg(): String? = rootInActiveWindow?.packageName?.toString()

    /** YouTube/Instagram me: next/prev reel, like, tap (pause/play). Sirf in do apps me chalta hai. */
    fun appCommand(kind: String): String {
        val root = rootInActiveWindow ?: return "Screen nahi padh paya"
        val pkg = root.packageName?.toString()
        if (pkg == null || pkg !in GESTURE_PKGS) return "Pehle YouTube ya Instagram kholo"
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val ok = when (kind) {
            "next" -> swipe(w * 0.5f, h * 0.78f, w * 0.5f, h * 0.22f)
            "prev" -> swipe(w * 0.5f, h * 0.22f, w * 0.5f, h * 0.78f)
            "tap" -> tap(w * 0.5f, h * 0.45f)
            "like" -> clickLike(root) || doubleTap(w * 0.5f, h * 0.45f)
            else -> false
        }
        return if (ok) "Ho gaya" else "Ye nahi ho paya"
    }

    private fun point(x: Float, y: Float) = Path().apply { moveTo(x, y) }

    private fun tap(x: Float, y: Float): Boolean = dispatchGesture(
        GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(point(x, y), 0, 50)).build(),
        null, null
    )

    private fun doubleTap(x: Float, y: Float): Boolean = dispatchGesture(
        GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(point(x, y), 0, 50))
            .addStroke(GestureDescription.StrokeDescription(point(x, y), 150, 50)).build(),
        null, null
    )

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val p = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        return dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, 250)).build(),
            null, null
        )
    }

    private fun clickLike(root: AccessibilityNodeInfo): Boolean {
        val re = Regex("^like\\b")
        val node = findNode(root, 0) { n ->
            val d = n.contentDescription?.toString()?.trim()?.lowercase()
            d != null && re.containsMatchIn(d)
        } ?: return false
        var cur: AccessibilityNodeInfo? = node
        while (cur != null && !cur.isClickable) cur = cur.parent
        return cur?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    private fun findNode(
        n: AccessibilityNodeInfo?, depth: Int, pred: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (n == null || depth > 25) return null
        if (pred(n)) return n
        for (i in 0 until n.childCount) {
            val r = findNode(n.getChild(i), depth + 1, pred)
            if (r != null) return r
        }
        return null
    }

    private fun findSend(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (pkg in WA_PACKAGES) {
            val hit = root.findAccessibilityNodeInfosByViewId("$pkg:id/send").firstOrNull()
            if (hit != null) return hit
        }
        return findByDesc(root, 0)
    }

    // WhatsApp ne view id badla ho to content description se dhundo
    private fun findByDesc(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (n == null || depth > 25) return null
        val d = n.contentDescription?.toString()?.trim()?.lowercase()
        if (n.isClickable && d != null && d in SEND_DESC) return n
        for (i in 0 until n.childCount) {
            val r = findByDesc(n.getChild(i), depth + 1)
            if (r != null) return r
        }
        return null
    }
}

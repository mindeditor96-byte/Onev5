package com.onev.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

/** Timer/reminder poora hone par chalta hai (service band ho tab bhi). */
class ReminderReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_TEXT = "text"
        private const val CHANNEL = "onev_reminder"
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        val text = intent.getStringExtra(EXTRA_TEXT) ?: "Reminder"
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "1V reminders", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("1V reminder")
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try {
            nm.notify((System.currentTimeMillis() and 0x7fffffff).toInt(), n)
        } catch (e: SecurityException) {
        }
        if (AssistantService.running) {
            try {
                ctx.startService(
                    Intent(ctx, AssistantService::class.java)
                        .setAction(AssistantService.ACTION_SAY)
                        .putExtra(AssistantService.EXTRA_TEXT, "Reminder. $text")
                )
            } catch (e: Exception) {
            }
        }
    }
}

package com.onev.assistant

import android.content.Context
import android.media.AudioManager

/**
 * Recognizer ki beep rokne ke liye system/notification awaaz 0 karta hai.
 * Asli volume disk par save rehta hai, isliye app crash ho tab bhi
 * agli baar app kholne par awaaz wapas aa jati hai.
 */
object BeepGuard {
    private val STREAMS = listOf(AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION)

    private fun prefs(c: Context) = c.getSharedPreferences("onev_beep", Context.MODE_PRIVATE)

    fun mute(c: Context) {
        try {
            val p = prefs(c)
            if (p.getBoolean("muted", false)) return // pehle se save hai (purane crash ke baad)
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val e = p.edit().putBoolean("muted", true)
            for (s in STREAMS) e.putInt("v$s", am.getStreamVolume(s))
            e.commit()
            for (s in STREAMS) {
                try {
                    am.setStreamVolume(s, 0, 0)
                } catch (ex: Exception) {
                }
            }
        } catch (ex: Exception) {
        }
    }

    fun restore(c: Context) {
        try {
            val p = prefs(c)
            if (!p.getBoolean("muted", false)) return
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            for (s in STREAMS) {
                val v = p.getInt("v$s", -1)
                if (v >= 0) {
                    try {
                        am.setStreamVolume(s, v, 0)
                    } catch (ex: Exception) {
                    }
                }
            }
            p.edit().clear().commit()
        } catch (ex: Exception) {
        }
    }
}

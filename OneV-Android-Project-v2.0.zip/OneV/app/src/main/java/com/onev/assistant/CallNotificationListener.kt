package com.onev.assistant

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * WhatsApp / Instagram ka incoming call notification pakadta hai (Answer + Decline buttons wala),
 * taaki 1V bolkar bata sake aur "utha lo / kaat do" sun sake.
 */
class CallNotificationListener : NotificationListenerService() {

    companion object {
        @Volatile
        var enabled = false

        private val PKGS = setOf("com.whatsapp", "com.whatsapp.w4b", "com.instagram.android")
        private val ANSWER = Regex("answer|accept|उत्तर|जवाब|स्वीकार|उठा|रिसीव", RegexOption.IGNORE_CASE)
        private val DECLINE = Regex("decline|reject|dismiss|अस्वीकार|अस्वीकृत|खारिज|काट|मना", RegexOption.IGNORE_CASE)
    }

    override fun onListenerConnected() {
        enabled = true
    }

    override fun onListenerDisconnected() {
        enabled = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in PKGS) return
        val n = sbn.notification ?: return
        if (n.category != Notification.CATEGORY_CALL) return
        val acts = n.actions ?: return
        var ans: PendingIntent? = null
        var dec: PendingIntent? = null
        for (a in acts) {
            val title = a.title?.toString() ?: continue
            if (ans == null && ANSWER.containsMatchIn(title)) ans = a.actionIntent
            else if (dec == null && DECLINE.containsMatchIn(title)) dec = a.actionIntent
        }
        if (ans == null || dec == null) return // ye ongoing call hai, incoming nahi
        if (sbn.key == VoipCalls.key) return // pehle hi bata chuke hain
        val label = n.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "Koi"
        VoipCalls.set(sbn.key, ans, dec, label)
        poke(AssistantService.ACTION_RING, label)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.packageName !in PKGS) return
        if (sbn.notification?.category != Notification.CATEGORY_CALL) return
        val remaining = try {
            activeNotifications.any {
                it.packageName in PKGS && it.notification?.category == Notification.CATEGORY_CALL
            }
        } catch (e: Exception) {
            false
        }
        if (!remaining) poke(AssistantService.ACTION_CALL_OVER, null)
    }

    private fun poke(action: String, text: String?) {
        if (!AssistantService.running) return
        try {
            startService(
                Intent(this, AssistantService::class.java)
                    .setAction(action)
                    .putExtra(AssistantService.EXTRA_TEXT, text)
            )
        } catch (e: Exception) {
        }
    }
}

package com.onev.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat

/** Normal (SIM) call utha/kaat. Android me ANSWER_PHONE_CALLS permission chahiye. */
object CallControl {
    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun act(ctx: Context, accept: Boolean): Boolean {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ANSWER_PHONE_CALLS) !=
            PackageManager.PERMISSION_GRANTED
        ) return false
        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        return try {
            if (accept) {
                tm.acceptRingingCall()
                true
            } else if (Build.VERSION.SDK_INT >= 28) {
                tm.endCall()
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }
}

/** WhatsApp/Instagram wagairah ke internet calls: notification ke Answer/Decline buttons. */
object VoipCalls {
    @Volatile var key: String? = null
    @Volatile var label: String? = null
    private var answer: PendingIntent? = null
    private var decline: PendingIntent? = null

    fun set(k: String, a: PendingIntent, d: PendingIntent, l: String) {
        key = k
        answer = a
        decline = d
        label = l
    }

    fun clear() {
        key = null
        label = null
        answer = null
        decline = null
    }

    fun act(accept: Boolean): Boolean {
        val pi = (if (accept) answer else decline) ?: return false
        return try {
            pi.send()
            true
        } catch (e: PendingIntent.CanceledException) {
            false
        }
    }
}

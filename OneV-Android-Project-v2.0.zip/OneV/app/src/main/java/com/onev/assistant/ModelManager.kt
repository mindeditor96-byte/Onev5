package com.onev.assistant

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Vosk offline voice model ek baar download hota hai (internet sirf isi ke liye),
 * uske baad bolna pehchanne ke liye internet kabhi nahi chahiye.
 */
object ModelManager {
    private const val HI_URL = "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip"
    private const val EN_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip"

    @Volatile
    var busy = false

    fun key(lang: String) = if (lang.startsWith("hi")) "hi" else "en"

    private fun url(lang: String) = if (key(lang) == "hi") HI_URL else EN_URL

    private fun root(ctx: Context) = File(ctx.filesDir, "vosk").apply { mkdirs() }

    private fun dir(ctx: Context, lang: String) = File(root(ctx), key(lang))

    fun isReady(ctx: Context, lang: String) = File(dir(ctx, lang), ".ready").exists()

    /** Zip ke andar ek folder hota hai (am/, conf/, graph/ wala); wahi model ka path hai. */
    fun modelPath(ctx: Context, lang: String): String {
        val d = dir(ctx, lang)
        if (File(d, "am").exists()) return d.absolutePath
        val inner = d.listFiles()?.firstOrNull { it.isDirectory && File(it, "am").exists() }
        return (inner ?: d).absolutePath
    }

    fun download(
        ctx: Context,
        lang: String,
        progress: (String) -> Unit,
        done: (Boolean, String) -> Unit
    ) {
        if (busy) {
            progress("Download pehle se chal raha hai...")
            return
        }
        busy = true
        val app = ctx.applicationContext
        Thread {
            var ok = false
            var msg = ""
            try {
                val target = dir(app, lang)
                target.deleteRecursively()
                target.mkdirs()
                val zip = File(root(app), key(lang) + ".zip.part")
                val c = URL(url(lang)).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.instanceFollowRedirects = true
                val total = c.contentLengthLong
                c.inputStream.use { inp ->
                    FileOutputStream(zip).use { out ->
                        val buf = ByteArray(64 * 1024)
                        var read = 0L
                        var last = 0
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            read += n
                            if (total > 0) {
                                val pct = (read * 100 / total).toInt()
                                if (pct >= last + 5) {
                                    last = pct
                                    progress("Offline model download: $pct%")
                                }
                            }
                        }
                    }
                }
                progress("Model unzip ho raha hai...")
                unzip(zip, target)
                zip.delete()
                File(target, ".ready").writeText("ok")
                ok = true
            } catch (e: Exception) {
                msg = e.message ?: "error"
                dir(app, lang).deleteRecursively()
            }
            busy = false
            done(ok, msg)
        }.start()
    }

    private fun unzip(zip: File, dest: File) {
        val base = dest.canonicalPath + File.separator
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val f = File(dest, e.name)
                if (!f.canonicalPath.startsWith(base)) throw SecurityException("bad zip entry")
                if (e.isDirectory) {
                    f.mkdirs()
                } else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { zin.copyTo(it) }
                }
                zin.closeEntry()
                e = zin.nextEntry
            }
        }
    }
}

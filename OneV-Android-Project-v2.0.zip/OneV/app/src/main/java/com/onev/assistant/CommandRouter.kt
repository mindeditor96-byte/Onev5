package com.onev.assistant

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.view.KeyEvent
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Bole gaye command ko action me badalta hai. Sab kuch offline. */
class CommandRouter(
    private val ctx: Context,
    private val remind: (Int, String) -> Unit
) {
    private val aliases = mapOf(
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "यूट्यूब" to "youtube",
        "क्रोम" to "chrome", "कैमरा" to "camera", "सेटिंग्स" to "settings", "सेटिंग" to "settings",
        "इंस्टाग्राम" to "instagram", "जीमेल" to "gmail", "मैप्स" to "maps", "मैप" to "maps",
        "टेलीग्राम" to "telegram", "गैलरी" to "gallery", "कैलकुलेटर" to "calculator",
        "घड़ी" to "clock", "फोन" to "phone"
    )

    private fun has(t: String, pattern: String) =
        Regex(pattern, RegexOption.IGNORE_CASE).containsMatchIn(t)

    companion object {
        /** Number me country code na ho (10 digit) to ye lagega. Apne desh ke hisaab se badlo. */
        const val DEFAULT_CC = "91"

        const val SEARCH_RE = "\\bsearch\\b|सर्च|dhundo|dhoondo|dhoondh|khojo|ढूंढ|खोज|\\bfind\\b"
        const val REEL_NEXT =
            "(next|agla|अगला|aage|आगे|neeche|नीचे|scroll down).*(reel|reels|short|shorts|रील|शॉर्ट)|" +
                "(reel|reels|short|shorts|रील|शॉर्ट).*(next|agla|अगला|neeche|नीचे)|scroll down|स्क्रॉल डाउन"
        const val REEL_PREV =
            "(previous|pichla|पिछला|peeche|पीछे|upar|ऊपर|scroll up).*(reel|reels|short|shorts|रील|शॉर्ट)|" +
                "(reel|reels|short|shorts|रील|शॉर्ट).*(previous|pichla|पिछला|peeche|पीछे|upar|ऊपर)|scroll up|स्क्रॉल अप"
        private val IG_NOISE = setOf(
            "instagram", "इंस्टाग्राम", "par", "pe", "per", "पर", "me", "mein", "में", "search", "सर्च",
            "karo", "kro", "करो", "dhundo", "khojo", "ढूंढो", "खोजो", "profile", "प्रोफाइल", "kholo",
            "khol", "खोलो", "dikhao", "दिखाओ", "ka", "ke", "ki", "ko", "1v"
        )
        const val YT_RE = SEARCH_RE + "|chalao|chala do|\\bplay\\b|sunao|dikhao|चलाओ|सुनाओ|दिखाओ|\\bsong\\b|gaana|gaane"

        private val SEND_WORDS = setOf(
            "message", "msg", "मैसेज", "sandesh", "bhejo", "bhej", "send", "karo", "kro", "likho",
            "likh", "भेजो", "भेज", "दो", "do", "kar", "de", "bolo", "bol", "kaho", "bata", "batao"
        )
        private val NAME_NOISE = SEND_WORDS + setOf(
            "whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "par", "pe", "per", "पर", "on", "se", "से",
            "sms", "एसएमएस", "text", "to", "please"
        )
        private val YT_NOISE = setOf(
            "youtube", "यूट्यूब", "yt", "par", "pe", "per", "पर", "me", "mein", "में", "search", "सर्च",
            "karo", "kro", "करो", "dhundo", "khojo", "ढूंढो", "खोजो", "chalao", "chala", "do", "de", "play",
            "dikhao", "दिखाओ", "चलाओ", "सुनाओ", "sunao", "video", "videos", "वीडियो", "ka", "ke", "ki",
            "का", "के", "की", "1v"
        )
        private val GOOGLE_NOISE = setOf(
            "google", "गूगल", "par", "pe", "per", "पर", "me", "mein", "में", "search", "सर्च", "karo", "kro",
            "करो", "dhundo", "dhoondo", "dhoondh", "khojo", "ढूंढो", "खोजो", "find", "for", "do", "de",
            "kijiye", "करें", "1v"
        )
        private val MAP_NOISE = setOf(
            "maps", "map", "मैप्स", "मैप", "google", "par", "pe", "per", "पर", "me", "mein", "में",
            "navigate", "नेविगेट", "directions", "direction", "raasta", "rasta", "रास्ता", "dikhao",
            "दिखाओ", "dhundo", "khojo", "search", "karo", "kro", "do", "de", "jao", "jana", "hai",
            "chalo", "to", "tak", "mujhe", "batao", "bata", "route", "ko", "ka", "ke", "ki", "1v"
        )
        private val CALL_NOISE = setOf(
            "call", "कॉल", "phone", "फोन", "laga", "lagao", "लगा", "लगाओ", "karo", "kro", "करो",
            "ko", "को", "do", "de", "dial", "please", "1v"
        )
    }

    private fun tokens(s: String) = s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private fun clean(tok: String) = tok.trim(',', '.', '!', '?', '।').lowercase(Locale.getDefault())

    private fun stripWords(s: String, words: Set<String>) =
        tokens(s).filter { clean(it) !in words }.joinToString(" ")

    // ---------- Contacts / number helpers ----------
    private class Contact(val name: String, val raw: String, val number: String)

    private fun hasContactsPermission() =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    private fun normalizeNumber(raw: String): String {
        val plus = raw.trim().startsWith("+")
        var d = raw.filter { it.isDigit() }
        if (plus) return d
        if (d.startsWith("00")) return d.drop(2)
        if (d.length == 11 && d.startsWith("0")) d = d.drop(1)
        return if (d.length == 10) DEFAULT_CC + d else d
    }

    private fun looksLikeNumber(s: String) =
        s.count { it.isDigit() } >= 7 && s.all { it.isDigit() || it in " +-" }

    private val DEV = mapOf(
        'क' to "k", 'ख' to "k", 'ग' to "g", 'घ' to "g", 'ङ' to "n", 'च' to "C", 'छ' to "C",
        'ज' to "j", 'झ' to "j", 'ञ' to "n", 'ट' to "t", 'ठ' to "t", 'ड' to "d", 'ढ' to "d",
        'ण' to "n", 'त' to "t", 'थ' to "t", 'द' to "d", 'ध' to "d", 'न' to "n", 'प' to "p",
        'फ' to "f", 'ब' to "b", 'भ' to "b", 'म' to "m", 'य' to "y", 'र' to "r", 'ल' to "l",
        'व' to "v", 'श' to "s", 'ष' to "s", 'स' to "s", 'ह' to "h"
    )

    /**
     * Naam ka "dhancha" (sirf vyanjan): Devanagari "राहुल" aur English "Rahul" dono "rhl" ban jate hain.
     * Isse Hindi me bola naam English likhe contact se match ho jata hai.
     */
    private fun skeleton(s: String): String {
        var lower = s.lowercase(Locale.ROOT)
        for ((a, b) in listOf(
            "chh" to "C", "ch" to "C", "sh" to "s", "kh" to "k", "gh" to "g", "th" to "t",
            "dh" to "d", "bh" to "b", "ph" to "f", "jh" to "j"
        )) lower = lower.replace(a, b)
        val sb = StringBuilder()
        for (ch in lower) {
            val out: String = when {
                DEV.containsKey(ch) -> DEV.getValue(ch)
                ch == 'C' -> "C"
                ch == 'w' -> "v"
                ch == 'z' -> "j"
                ch == 'q' || ch == 'c' -> "k"
                ch in 'a'..'z' && ch !in "aeiou" -> ch.toString()
                else -> ""
            }
            for (c in out) if (sb.isEmpty() || sb[sb.length - 1] != c) sb.append(c)
        }
        return sb.toString()
    }

    private fun fuzzyContact(who: String): Contact? {
        val q = skeleton(who)
        if (q.length < 2) return null
        return try {
            val phone = ContactsContract.CommonDataKinds.Phone
            ctx.contentResolver.query(
                phone.CONTENT_URI, arrayOf(phone.DISPLAY_NAME, phone.NUMBER), null, null, null
            )?.use { c ->
                var best: Contact? = null
                var bestScore = Int.MAX_VALUE
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val sk = skeleton(n)
                    val idx = sk.indexOf(q)
                    if (idx < 0) continue
                    // shuru me milne wala behtar, phir chhota naam
                    val score = idx * 100 + n.length
                    if (score < bestScore) {
                        bestScore = score
                        best = Contact(n, num, normalizeNumber(num))
                    }
                }
                best
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun resolveContact(who: String): Contact? {
        if (looksLikeNumber(who)) return Contact(who, who.filter { it.isDigit() || it == '+' }, normalizeNumber(who))
        if (!hasContactsPermission()) return null
        return exactContact(who) ?: fuzzyContact(who)
    }

    private fun exactContact(who: String): Contact? {
        return try {
            val phone = ContactsContract.CommonDataKinds.Phone
            ctx.contentResolver.query(
                phone.CONTENT_URI,
                arrayOf(phone.DISPLAY_NAME, phone.NUMBER),
                "${phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$who%"),
                null
            )?.use { c ->
                var best: Contact? = null
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val b = best
                    if (b == null || n.length < b.name.length) best = Contact(n, num, normalizeNumber(num))
                }
                best
            }
        } catch (e: Exception) {
            null
        }
    }

    /** "rahul ko ... message" -> (rahul, message). Hindi ("ko") aur English ("to") dono. */
    private fun parseRecipient(cmd: String): Pair<String, String>? {
        val tk = tokens(cmd)
        val idx = tk.indexOfFirst { clean(it) == "ko" || clean(it) == "को" }
        if (idx > 0) {
            val name = tk.subList(0, idx).filter { clean(it) !in NAME_NOISE }.joinToString(" ").trim()
            if (name.isBlank()) return null
            val rest = tk.drop(idx + 1)
                .dropWhile { clean(it) in SEND_WORDS }
                .dropLastWhile { clean(it) in SEND_WORDS }
                .joinToString(" ")
            return name to rest
        }
        val to = tk.indexOfFirst { clean(it) == "to" }
        if (to < 0 || to + 1 >= tk.size) return null
        val name = tk[to + 1].trim(',', '.', ':')
        val rest = tk.drop(to + 2)
            .dropWhile { clean(it) in SEND_WORDS }
            .dropLastWhile { clean(it) in SEND_WORDS }
            .joinToString(" ")
        return name to rest
    }

    private fun launch(i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    private fun openUrl(url: String, ok: String): String =
        if (launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))) ok else "Browser nahi khul paya"

    // ---------- WhatsApp / SMS ----------
    private fun sendWhatsApp(cmd: String): String {
        val (who, msg) = parseRecipient(cmd) ?: return "Kisko message bhejna hai?"
        if (msg.isBlank()) return "Message kya bhejna hai? Poora command dobara bolo"
        if (!looksLikeNumber(who) && !hasContactsPermission()) return "Contacts ki permission do"
        val c = resolveContact(who) ?: return "$who naam ka contact nahi mila"
        val uri = Uri.parse("https://wa.me/${c.number}?text=${Uri.encode(msg)}")
        return confirmOrRun("${c.name} ko WhatsApp par ye message: $msg.") {
            val auto = AutoSendService.isEnabled()
            if (auto) AutoSendService.arm()
            var result = "WhatsApp nahi khul paya"
            for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b", null)) {
                val i = Intent(Intent.ACTION_VIEW, uri)
                if (pkg != null) i.setPackage(pkg)
                if (launch(i)) {
                    result = if (auto) "${c.name} ko WhatsApp par bhej raha hoon"
                    else "${c.name} ko message taiyaar hai, bas Send dabaiye. " +
                        "Apne aap bhejne ke liye app me Auto send ON karo"
                    break
                }
            }
            result
        }
    }

    private fun sendSms(cmd: String): String {
        val (who, msg) = parseRecipient(cmd) ?: return "Kisko SMS bhejna hai?"
        if (msg.isBlank()) return "SMS me kya likhna hai? Poora command dobara bolo"
        if (!looksLikeNumber(who) && !hasContactsPermission()) return "Contacts ki permission do"
        val c = resolveContact(who) ?: return "$who naam ka contact nahi mila"
        val dest = c.raw.filter { it.isDigit() || it == '+' }
        return confirmOrRun("${c.name} ko SMS: $msg.") {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED
            ) {
                try {
                    @Suppress("DEPRECATION")
                    val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
                    else SmsManager.getDefault()
                    sm.sendMultipartTextMessage(dest, null, sm.divideMessage(msg), null, null)
                    "${c.name} ko SMS bhej diya"
                } catch (e: Exception) {
                    "SMS nahi ja paya"
                }
            } else {
                val i = Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", dest, null))
                    .putExtra("sms_body", msg)
                if (launch(i)) "${c.name} ko SMS taiyaar hai, bas Send dabaiye (SMS permission do to apne aap jayega)"
                else "SMS app nahi khul paya"
            }
        }
    }

    // ---------- Search / maps ----------
    private fun youtube(t: String): String {
        val q = stripWords(t, YT_NOISE)
        if (q.isBlank()) return openApp(t) ?: "YouTube nahi mila"
        val ok = "YouTube par $q search kar raha hoon"
        val i = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
        return if (launch(i)) ok
        else openUrl("https://www.youtube.com/results?search_query=${Uri.encode(q)}", ok)
    }

    private fun googleSearch(t: String): String {
        val q = stripWords(t, GOOGLE_NOISE)
        if (q.isBlank()) return "Google par kya search karna hai?"
        return webSearch(q, "Google par $q search kar raha hoon")
    }

    private fun webSearch(q: String, ok: String): String {
        val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
        return if (launch(i)) ok else openUrl("https://www.google.com/search?q=${Uri.encode(q)}", ok)
    }

    private fun maps(t: String): String {
        val nav = has(t, "navigate|direction|raasta|rasta|रास्ता|नेविगेट|route")
        val q = stripWords(t, MAP_NOISE)
        if (q.isBlank()) return "Kaunsi jagah ka batana hai?"
        val uri = Uri.parse(
            if (nav) "google.navigation:q=${Uri.encode(q)}" else "geo:0,0?q=${Uri.encode(q)}"
        )
        val withPkg = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps")
        val ok = if (nav) "$q ka rasta khol raha hoon" else "Maps par $q dhundh raha hoon"
        if (launch(withPkg) || launch(Intent(Intent.ACTION_VIEW, uri))) return ok
        return "Maps app nahi mila"
    }

    // ---------- Alarm / settings ----------
    private fun alarm(t: String): String {
        if (has(t, "min|मिनट|hour|ghant|घंट|second|\\bsec\\b")) return timer(t)
        val m = Regex("(\\d{1,2})(?:\\s*[:.\\s]\\s*(\\d{2}))?").find(t)
            ?: return "Kitne baje ka alarm lagana hai?"
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].toIntOrNull() ?: 0
        val night = has(t, "raat|रात")
        val pm = night || has(t, "\\bpm\\b|p\\.m|shaam|sham|शाम|dopahar|दोपहर")
        val am = has(t, "\\bam\\b|subah|सुबह|savere")
        if (pm && h < 12) h += 12
        if (night && h == 12) h = 0
        if (am && h == 12) h = 0
        if (h > 23 || min > 59) return "Samay samajh nahi aaya"
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "1V")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(i)) String.format(Locale.US, "%d:%02d baje ka alarm laga diya", h, min)
        else "Alarm nahi lag paya"
    }

    private fun systemSettings(t: String): String {
        val bt = has(t, "bluetooth|ब्लूटूथ")
        val action = if (bt) Settings.ACTION_BLUETOOTH_SETTINGS else Settings.ACTION_WIFI_SETTINGS
        val name = if (bt) "Bluetooth" else "WiFi"
        return if (launch(Intent(action))) "Android ab $name apne aap on off karne nahi deta, isliye settings khol di"
        else "Settings nahi khuli"
    }

    // ---------- Bhejne se pehle confirmation ----------
    private var pending: (() -> String)? = null
    val hasPending: Boolean get() = pending != null

    fun clearPending() {
        pending = null
    }

    private fun confirmOn() =
        ctx.getSharedPreferences("onev", Context.MODE_PRIVATE).getBoolean("confirm_send", true)

    /** Haan/nahi ka jawab. Sirf saaf "haan" par hi bhejta hai, baaki sab par cancel. */
    fun confirm(text: String): String {
        val p = pending
        pending = null
        if (p == null) return route(text)
        val t = text.lowercase(Locale.getDefault())
        return when {
            has(t, "nahi|nahin|\\bno\\b|cancel|\\bmat\\b|ruko|नहीं|नही|मत|रुको") -> "Theek hai, nahi bheja"
            has(t, "\\b(haan|han|ha|yes|yeah|ok|okay|send|bhejo|bhej do|kar do)\\b|हाँ|हां|हा|जी|भेजो|भेज दो|ठीक") -> p()
            else -> "Samajh nahi aaya, isliye nahi bheja"
        }
    }

    private fun confirmOrRun(prompt: String, action: () -> String): String {
        if (!confirmOn()) return action()
        pending = action
        return "$prompt Bhejun? Haan ya nahi bolo"
    }

    fun route(cmd: String): String {
        pending = null
        val t = cmd.lowercase(Locale.getDefault()).trim()
        return when {
            has(t, "note.*(padh|sun|dikha|bata|read)|पढ़.*नोट|नोट.*पढ़") -> readNotes()
            has(t, "\\bnotes?\\b|नोट|yaad rakh|याद रख") -> writeNote(cmd)
            has(t, "whatsapp|व्हाट्सएप|व्हाट्सऐप") &&
                has(t, "message|msg|मैसेज|bhej|भेज|send|likho|लिखो|bol|kaho") &&
                parseRecipient(cmd) != null -> sendWhatsApp(cmd)
            has(t, "\\bsms\\b|एसएमएस|text message") && parseRecipient(cmd) != null -> sendSms(cmd)
            has(t, "instagram|इंस्टाग्राम") && has(t, "profile|प्रोफाइल|reel|रील|" + SEARCH_RE) -> instagram(t)
            has(t, "youtube|यूट्यूब") && has(t, YT_RE) -> youtube(t)
            has(t, "navigate|direction|raasta|rasta|रास्ता|नेविगेट") ||
                (has(t, "\\bmaps?\\b|मैप") && has(t, SEARCH_RE)) -> maps(t)
            has(t, SEARCH_RE) -> googleSearch(t)
            has(t, REEL_NEXT) -> appGesture("next")
            has(t, REEL_PREV) -> appGesture("prev")
            has(t, "\\blike\\b|लाइक") && !has(t, "dislike|unlike") -> appGesture("like")
            has(t, "\\b(time|date)\\b|kitne baje|samay|टाइम|समय|कितने बजे|तारीख") -> time()
            has(t, "mausam|weather|मौसम") -> webSearch("weather today", "Mausam Google par dikha raha hoon")
            has(t, "battery|बैटरी") -> battery()
            has(t, "torch|flashlight|टॉर्च|टार्च|फ्लैशलाइट") ->
                torch(!has(t, "\\boff\\b|band|bujha|बंद|बुझा"))
            has(t, "volume|वॉल्यूम|आवाज") -> volume(t)
            has(t, "call.*(kaat|band|cut|end)|hang ?up|कॉल.*(काट|बंद)|फोन रख") -> hangUp()
            has(t, "\\bcall\\b|phone laga|कॉल|फोन लगा") -> call(t)
            has(t, "alarm|अलार्म") -> alarm(t)
            has(t, "timer|reminder|yaad dila|याद दिला|टाइमर|रिमाइंडर") -> timer(t)
            has(t, "wifi|wi-fi|वाईफाई|वाई-फाई|वाई फाई|bluetooth|ब्लूटूथ") -> systemSettings(t)
            has(t, "\\bpause\\b|roko|रोको|रोक दो|पॉज|gaana band") -> playPause(true)
            has(t, "\\bresume\\b|jaari|जारी") ||
                (has(t, "\\bplay\\b|chalao|चलाओ") && !has(t, "play store|प्ले स्टोर")) -> playPause(false)
            has(t, "\\bnext\\b|agla|अगला") -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT, "Agla")
            has(t, "\\bprevious\\b|pichla|पिछला") -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Pichla")
            has(t, "open|kholo|khol|start|chalu|चालू|खोल|शुरू") ->
                openApp(t) ?: "Is naam ka app nahi mila"
            else -> "Maaf kijiye, ye command mujhe abhi nahi aata. " +
                "Main time, battery, torch, volume, call, alarm, timer, note, WhatsApp aur SMS message, " +
                "YouTube, Instagram aur Google search, maps, mausam, music control aur app kholna kar sakta hoon."
        }
    }

    private fun time(): String =
        "Abhi " + SimpleDateFormat("hh:mm a, dd MMMM yyyy", Locale.getDefault()).format(Date()) + " hai"

    private fun battery(): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return "Battery ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} percent hai"
    }

    private fun torch(on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "Is phone me flash nahi mila"
            cm.setTorchMode(id, on)
            if (on) "Torch chalu kar di" else "Torch band kar di"
        } catch (e: Exception) {
            "Torch nahi chal payi"
        }
    }

    private fun volume(t: String): String {
        val pct = when {
            has(t, "\\bmax\\b|full|फुल") -> 100
            has(t, "mute|म्यूट") -> 0
            else -> Regex("\\d+").find(t)?.value?.toIntOrNull()
                ?: return relativeVolume(t)
        }.coerceIn(0, 100)
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (pct * max / 100.0).roundToInt(), AudioManager.FLAG_SHOW_UI)
        return "Volume $pct percent kar diya"
    }

    private fun relativeVolume(t: String): String {
        val up = has(t, "badha|increase|\\bup\\b|zyada|ज्यादा|बढ़ा")
        val down = has(t, "kam|ghata|decrease|down|कम|घटा")
        if (!up && !down) return "Volume kitna percent karna hai?"
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        return if (up) "Volume badha diya" else "Volume kam kar diya"
    }

    private fun call(t: String): String {
        var raw = t.filter { it.isDigit() }
        var name = ""
        if (raw.length < 5) {
            val who = stripWords(t, CALL_NOISE)
            if (who.isBlank()) return "Number ya naam batao"
            if (!hasContactsPermission()) return "Contacts ki permission do, ya number batao"
            val c = resolveContact(who) ?: return "$who naam ka contact nahi mila"
            raw = c.raw
            name = c.name
        }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED
        ) return "Call ki permission do"
        val ok = launch(Intent(Intent.ACTION_CALL, Uri.fromParts("tel", raw, null)))
        return if (ok) "${name.ifEmpty { raw }} ko call laga raha hoon" else "Call nahi lag payi"
    }

    private fun spoken(total: Int): String {
        val h = total / 3600
        val m = (total % 3600) / 60
        val sec = total % 60
        return listOfNotNull(
            if (h > 0) "$h ghanta" else null,
            if (m > 0) "$m minute" else null,
            if (sec > 0) "$sec second" else null
        ).joinToString(" ")
    }

    private fun timer(t: String): String {
        val n = Regex("\\d+").find(t)?.value?.toIntOrNull() ?: return "Kitne der ka timer lagana hai?"
        val mult = when {
            has(t, "min|मिनट") -> 60
            has(t, "hour|ghant|घंट") -> 3600
            else -> 1
        }
        val total = n * mult
        if (total <= 0) return "Timer ka time zero nahi ho sakta"
        if (total > 24 * 3600) return "Itna lamba timer nahi laga sakta, 24 ghante tak batao"
        val label = t.replace(
            Regex(
                "\\d+|timer|reminder|minutes?|min|seconds?|sec|hours?|ghante?|ghanta|baad|lagao|laga|set|" +
                    "yaad dila|\\bdo\\b|\\bde\\b|karo|\\bka\\b|\\bke\\b|\\bki\\b|\\bin\\b|" +
                    "लगा|याद दिला|मिनट|सेकंड|घंटे?|टाइमर|रिमाइंडर"
            ), " "
        ).replace(Regex("\\s+"), " ").trim()
        remind(total, label)
        return "Theek hai, ${spoken(total)} baad yaad dila dunga"
    }

    private fun notesFile() = File(ctx.filesDir, "notes.txt")

    private fun writeNote(cmd: String): String {
        // sirf shuru/ant ke command words hatao, note ke beech ke shabd nahi chhedte
        val opts = RegexOption.IGNORE_CASE
        val lead = Regex(
            "^\\s*(please\\s+)?(notes?|नोट|yaad rakh(o)?|याद रख(ो)?)\\s*" +
                "(likho|likh lo|likh do|likh|kar lo|karo|kar do|save karo|save kar|lo|do|लिखो|लिख लो|कर लो|करो)?\\s*[:,\\-]?\\s*",
            opts
        )
        val tail = Regex(
            "\\s*(ye|yeh|isko|ise)?\\s*(notes?|नोट)?\\s*" +
                "(likho|likh lo|likh do|likh|kar lo|karo|kar do|save karo|save kar|लिखो|लिख लो|कर लो|करो)\\s*$",
            opts
        )
        val body = cmd.replace(lead, "").replace(tail, "").trim(' ', ',', '.', ':')
        if (body.isEmpty()) return "Kya likhna hai?"
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        notesFile().appendText("[$stamp] $body\n")
        return "Note save ho gaya"
    }

    private fun readNotes(): String {
        val f = notesFile()
        if (!f.exists()) return "Koi note nahi hai"
        val last = f.readLines().filter { it.isNotBlank() }.takeLast(3)
        if (last.isEmpty()) return "Koi note nahi hai"
        return "Aakhri notes: " + last.joinToString(". ") { it.substringAfter("] ") }
    }

    @Suppress("DEPRECATION")
    // ---------- Instagram / media / app gestures ----------
    private fun instagram(t: String): String {
        if (has(t, "reel|रील")) {
            val url = "https://www.instagram.com/reels/"
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.instagram.android")
            return if (launch(i)) "Instagram reels khol raha hoon" else openUrl(url, "Reels khol raha hoon")
        }
        val q = stripWords(t, IG_NOISE)
        if (q.isBlank()) return openApp(t) ?: "Instagram nahi mila"
        if (q.any { it.code > 127 }) {
            return (openApp(t) ?: "Instagram nahi mila") +
                ". Profile ka username English me chahiye, isliye app khol diya"
        }
        val user = q.replace(" ", "").lowercase(Locale.ROOT)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("http://instagram.com/_u/$user"))
            .setPackage("com.instagram.android")
        return if (launch(i)) "Instagram par $user ka profile khol raha hoon"
        else openUrl("https://www.instagram.com/$user/", "$user ka profile khol raha hoon")
    }

    private fun appGesture(kind: String): String {
        val s = AutoSendService.instance
            ?: return "Ye karne ke liye app me Accessibility (1V Auto Send) ON karo"
        return s.appCommand(kind)
    }

    private fun mediaKey(code: Int, ok: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ok
    }

    private fun playPause(pause: Boolean): String {
        val s = AutoSendService.instance
        if (s != null && s.foregroundPkg() == "com.instagram.android") return s.appCommand("tap")
        return mediaKey(
            if (pause) KeyEvent.KEYCODE_MEDIA_PAUSE else KeyEvent.KEYCODE_MEDIA_PLAY,
            if (pause) "Ruka diya" else "Chala diya"
        )
    }

    private fun hangUp(): String =
        if (CallControl.act(ctx, false)) "Call kaat diya" else "Call kaat nahi paya, Phone permission check karo"

    /** Incoming call ka number -> contact naam (Contacts permission ho to). */
    fun nameForNumber(num: String): String? {
        if (!hasContactsPermission()) return null
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num))
            ctx.contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    private fun openApp(t: String): String? {
        var q = t
        for ((k, v) in aliases) q = q.replace(k, v)
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        var best: ResolveInfo? = null
        var bestLabel = ""
        for (ri in apps) {
            val label = ri.loadLabel(pm).toString().lowercase(Locale.getDefault())
            if (label.length >= 3 && q.contains(label) && label.length > bestLabel.length) {
                best = ri
                bestLabel = label
            }
        }
        if (best == null) {
            // Hindi me bola gaya app naam (जैसे "क्रोम") ko English label se milao
            val tk = tokens(q)
            for (ri in apps) {
                val label = ri.loadLabel(pm).toString().lowercase(Locale.getDefault())
                val sk = skeleton(label).replace('C', 'k')
                if (sk.length < 3 || label.length <= bestLabel.length) continue
                var hit = false
                for (n in 1..3) {
                    for (st in 0..(tk.size - n)) {
                        val cand = tk.subList(st, st + n).joinToString(" ")
                        if (skeleton(cand).replace('C', 'k') == sk) hit = true
                    }
                }
                if (hit) {
                    best = ri
                    bestLabel = label
                }
            }
        }
        val pkg = best?.activityInfo?.packageName ?: return null
        val intent = pm.getLaunchIntentForPackage(pkg) ?: return null
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent)
            "$bestLabel khol raha hoon"
        } catch (e: Exception) {
            "App nahi khul paya"
        }
    }
}

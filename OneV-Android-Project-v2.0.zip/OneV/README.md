# 1V - Offline Personal Assistant (Android APK)

Bolo "1V" aur phone sunega. Offline voice model download hone ke baad bolna pehchanne ke liye internet nahi chahiye (WhatsApp/YouTube/Instagram kholne aur search karne ke liye wo apps apna internet khud use karte hain).

## Kya kar sakta hai
- "1V, time batao" / "1V, battery kitni hai"
- "1V, torch on/off karo"
- "1V, volume 60 karo" / "volume max"
- "1V, chrome kholo" (phone me jo bhi app installed ho, naam bolo)
- "1V, call 9876543210" / "1V, Rahul ko call karo" (contact naam se)
- "1V, whatsapp par Rahul ko message bhejo kal milte hain" (Auto-send ON ho to apne aap bhej deta hai)
- "1V, Rahul ko sms bhejo main late hoon" (SMS permission ho to seedha chala jata hai)
- "1V, youtube par arijit singh ke gaane chalao"
- "1V, google par aaj ka cricket score search karo"
- "1V, maps par nearest ATM dhundo" / "1V, airport ka rasta dikhao"
- "1V, subah 7 baje ka alarm lagao"
- "1V, mausam batao" / "1V, wifi" / "1V, bluetooth" (settings khulti hai)
- "1V, volume badhao / kam karo"
- "1V, 5 minute ka timer lagao"
- "1V, note likho doodh lana hai" / "notes padho"
- "1V, instagram par <username> profile kholo" / "1V, instagram reels kholo"
- "1V, agla reel" / "pichla reel" / "like karo" (YouTube Shorts aur Instagram Reels me; Accessibility ON chahiye)
- "1V, pause" / "play" / "next" / "pichla" (YouTube, music apps)
- **Call aane par:** 1V bolta hai "Rahul ka call aa raha hai. Utha loon ya kaat doon?" Aap "utha lo" ya "kaat do" bolo (1V bole bina bhi chalta hai). Normal call aur WhatsApp/Instagram call dono.
- "1V, bye" (band)

Sirf "1V" bolo to wo "Haan, bataiye?" bolega, phir command do.

## APK banane ke 2 tareeke

### A) Android Studio (computer par)
1. Android Studio (Koala ya naya) install karo.
2. File > Open > is `OneV` folder ko chuno. Gradle sync hone do.
3. Build > Build APK(s). APK yahan milega: `app/build/outputs/apk/debug/app-debug.apk`
4. APK phone me bhejo aur install karo ("Unknown sources" allow karna padega).

### B) Bina Android Studio ke (GitHub se)
1. github.com par free account banao aur naya repository banao.
2. Is folder ki saari files (`.github` folder samet) us repo me upload karo.
3. Repo ke **Actions** tab me "Build APK" chalega (5-8 minute).
4. Run khatam hone par neeche **Artifacts > 1V-apk** download karo. Usme `app-debug.apk` hai.

## Pehli baar phone par setup
1. App kholo, **Shuru karo** dabao.
2. Mic, Phone aur Notification permission Allow karo.
3. Contacts permission bhi allow karo (naam se call/WhatsApp/SMS ke liye).
3. "Display over other apps" allow karo (iske bina background me app/call nahi khulte).
4. **Offline voice model download karo** (app me "Offline voice model" button, ~40 MB, ek baar, WiFi par). Uske baad 1V band karke dobara shuru karo. Ab bolna pehchanne me internet kabhi use nahi hota aur beep bhi nahi aati. Model download na ho to 1V Google speech par chalta hai (wo online ja sakta hai; "Google offline pack" button backup hai).
5. **Call utha/kaat ke liye:** Phone, Call log aur "Answer calls" permission allow karo. WhatsApp/Instagram call ke liye "WhatsApp/Instagram call control" button dabakar Notification access me **1V Auto Send** ON karo.
6. Reels/Shorts control aur WhatsApp auto-send ke liye "Auto-send + Reels/Shorts control" button se Accessibility ON karo.
7. Battery setting me 1V ko **Unrestricted** karo, warna Android band kar dega.

## Dhyan rakhne wali baatein
- Chalte waqt app system/notification awaaz band rakhta hai (recognizer ki beep rokne ke liye) aur band karne par wapas kar deta hai. Agar app crash ho jaye, to agli baar app kholte hi awaaz wapas aa jati hai.
- Timer/reminder ab AlarmManager se chalta hai: app band ho tab bhi notification aata hai (doze mode me thoda late ho sakta hai).
- "1V" ke alawa bole gaye shabd na screen par dikhte hain na save hote hain.
- **WhatsApp auto-send:** app me "WhatsApp auto-send ON karo" button dabao, Accessibility list me **1V Auto Send** ON karo. Ye service sirf WhatsApp/WhatsApp Business me chalti hai aur sirf tab Send dabati hai jab 1V ne abhi message taiyaar kiya ho. Agar toggle grey ho (Android 13+): Settings > Apps > 1V > teen dot (⋮) > **Allow restricted settings**, phir dobara try karo. Service ON na ho to chat khulti hai aur Send aapko dabana padta hai.
- **Bhejne se pehle poochna (default ON):** WhatsApp/SMS se pehle 1V bolta hai "X ko ye message: ... Bhejun?" Aap "haan" bolo to hi jata hai, "nahi" ya kuch aur bolo to cancel. App ke button se ye OFF kar sakte ho (tab seedha bhej dega).
- Contact naam Hindi me bolo ya English me, dono match hote hain (राहुल = Rahul).
- 10 digit number par country code 91 lagta hai (`CommandRouter.DEFAULT_CC` me badal sakte ho).
- WiFi/Bluetooth Android ab apne aap on/off nahi karne deta, isliye sirf unki settings khulti hain.
- Offline engine (Vosk) lagataar sunta hai bina beech me ruke, isliye "1V" miss nahi hota. Isme ~150-300 MB RAM lagti hai aur battery bhi jaldi jati hai.
- Hindi model Hinglish ko Devanagari me likhta hai (जैसे "टाइम बताओ"). 1V use samajhta hai, par Google speech jitna saaf nahi. Model chhota hai, to kabhi galat sunega; saaf aur dheere bolo.
- Hindi model English naam/username (Instagram) ko Devanagari me likhta hai, isliye Instagram profile ke liye English model (Bhasha button) chuno.
- Call ke dauran Android 10+ mic apps ko nahi deta, isliye call ke beech bolkar call nahi kat sakte. Call aane par (ringing) utha/kaat kaam karta hai.
- WhatsApp/Instagram call ka Answer/Decline button notification se uthaya jata hai; app ka notification design badla to ye kaam karna band kar sakta hai.
- Lagataar mic sunne se battery jaldi khatam hoti hai.
- Is version me general baat-cheet (ChatGPT jaisa) nahi hai, sirf upar wale commands. 2 GB RAM me bada AI model nahi chalta.
- Naye commands `CommandRouter.kt` me jodte ho.
